/** Automatically generated file. DO NOT MODIFY */
package tw.com.prlific.pl2303hxdmodemstatus;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}