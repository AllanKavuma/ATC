#! /bin/sh

IsTargzFile()
{
	FILENAME=$1
	TMPVAL=${FILENAME%".tar.gz"}
	test "${TMPVAL}" = "${FILENAME}" 
	if [ $? -eq "0" ];then
		return 1 
	else
		return 0
	fi
}

IsZipFile()
{
	FILENAME=$1
	TMPVAL=${FILENAME%".zip"}
	test "${TMPVAL}" = "${FILENAME}" 
	if [ $? -eq "0" ]; then
		return 1
	else
		return 0
	fi
}

#��Ʒ�ɸ���ʵ��keeper�����ļ��洢λ���޸�ChangeAppStartPath()
ChangeAppStartPath()
{
	if [ -e /mnt/log/update/config.kp ]; then
		FILEPATH="/mnt/log/update/"
		FILENAME="config.kp"
		BAKFILENAME="config_bak.kp"
		cp "${FILEPATH}${FILENAME}" "${FILEPATH}${BAKFILENAME}"
		sed -i 's:/app_bin0:/app_bin5:' ${FILEPATH}${BAKFILENAME}
		sed -i 's:/app_bin1:/app_bin0:' ${FILEPATH}${BAKFILENAME}
		sed -i 's:/app_bin5:/app_bin1:' ${FILEPATH}${BAKFILENAME}
		excute_shell_order "rm -f  ${FILEPATH}${FILENAME}"
		excute_shell_order "mv ${FILEPATH}${BAKFILENAME} ${FILEPATH}${FILENAME}"
	else
		if [ ! -d /mnt/log/update ];then
			mkdir /mnt/log/update
		fi
		echo $RUNNING_APP | grep app_bin0 > /dev/null 2>&1
        	if [ $? -ne "0" ]; then
			echo "#name  mem(kB) cpu  ommand" > /mnt/log/update/config.kp
			echo "app_arm 128000 100  /mnt/app_bin0/bin_arm/app_arm" >> /mnt/log/update/config.kp
			echo "app_arm 128000 100  /mnt/app_bin1/bin_arm/app_arm" >> /mnt/log/update/config.kp
        	else
			echo "#name  mem(kB) cpu  ommand" > /mnt/log/update/config.kp
			echo "app_arm 128000 100  /mnt/app_bin1/bin_arm/app_arm" >> /mnt/log/update/config.kp
			echo "app_arm 128000 100  /mnt/app_bin0/bin_arm/app_arm" >> /mnt/log/update/config.kp
        	fi
	fi
	return 0
}

excute_shell_order()
{
	for try_cnt in `seq 1 10`
	do
	$1
	retcode=$?
		if [ $retcode -eq 0 ];then 
			return 0
		fi	
		echo "`date` [APP update] INFO: can not excute shell: \"$1\", retcode: $retcode" >> /home/update/update.log
		usleep 100000
	done
	echo "`date` [APP update]  ERR: can not excute shell: \"$1\", retcode: $retcode" >> /home/update/update.log
	echo "ERR: can not excute shell: \"$1\", retcode: $retcode"
	exit 5
}

#����app_arm���̣����������ɱ��ռ��/dev/watchdog�Ľ���������ι��
#��Ʒ����ʵ������ʱ���ں��ʵĵط����øú���
watch_app_arm()
{
	pidof app_arm > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		for kill_cnt in `seq 1 1000`
		do
			(watchdog -t 10ms /dev/watchdog) > /dev/null 2>&1
			if [ $? -eq 0 ]; then
				echo "`date` [BSP update] WARN: app isn't running, kill keeper times: $kill_cnt" >> /home/update/update.log
				return 0
			fi
			
			RUNNING_PROCESS=`ps |grep -v grep |awk '{print $1}' |grep -v PID`
			for process_id in $RUNNING_PROCESS
			do
				(ls -lh /proc/$process_id/fd |grep /dev/watchdog) >/dev/null  2>&1
				if [ $? -eq 0 ]; then 
					kill -9 $process_id
				fi
			done

			usleep 10000
		done
		echo "`date` [BSP update]  ERR: can not watch dog" >> /home/update/update.log
		echo "ERR: can not watch dog"
		exit 1
	fi
	return 0
}

#add by KF70786
#����APP���̲�����keeper������ռ/dev/watchdog�豸����,�Լ��ӹ�ι��
exit_app_process()
{
	pidof app_arm > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		for kill_cnt in `seq 1 1000`
		do
			#Ϊ���ͷ�app����ռ�õ�flash�ռ䣬��app����ɱ����������watch app_arm
			#echo $kill_cnt >> /home/update/update.log
			(kill -9 `pidof app_arm`) > /dev/null 2>&1
			pidof app_arm > /dev/null 2>&1
			if [ $? -ne 0 ]; then
				echo "`date` [BSP update] INFO: kill app times: $kill_cnt and watch app_arm immediately" >> /home/update/update.log
				break
			fi	
				
			usleep 10000
		done
		if [ 1000 -eq $kill_cnt ];then
			echo "`date` [BSP update]  ERR: can not kill app" >> /home/update/update.log
			echo "ERR: can not kill app"
			return 1
		fi
	fi
	
	#����APP�󣬽���keeper������ռ/dev/watchdog�豸����,�Լ��ӹ�ι��
	for kill_cnt in `seq 1 1000`
	do
		(watchdog -t 10ms /dev/watchdog) > /dev/null 2>&1
		if [ $? -eq 0 ]; then
			echo "`date` [BSP update] WARN: app isn't running, kill keeper times: $kill_cnt" >> /home/update/update.log
			return 0
		fi
			
		RUNNING_PROCESS=`ps |grep -v grep |awk '{print $1}' |grep -v PID`
		for process_id in $RUNNING_PROCESS
		do
			(ls -lh /proc/$process_id/fd |grep /dev/watchdog) >/dev/null  2>&1
			if [ $? -eq 0 ]; then 
				kill -9 $process_id
			fi
		done

		usleep 10000
	done
	echo "`date` [BSP update]  ERR: can not watch dog" >> /home/update/update.log
	echo "ERR: can not watch dog"
	return 1
}

#update_soֻ֧������"libname_�汾��*"��so��
update_so()
{
	lib_name=${1%_*}
	lib_num=`find /home/so_bin/ -name ""$lib_name"_*" |wc -l`

	if [ $lib_num -eq "0" ]; then
		#so�ļ������ڣ�ֱ�Ӹ���
		excute_shell_order "cp  ${INPUTPATH}/$1		/home/so_bin" 
	elif [ $lib_num -eq "1" ]; then
		if ! [ -e /home/so_bin/$1 ]; then
			#��ǰ�Ѵ��ڵ�so���ļ���Ҫ���µ�so���ļ���һ�£�����
			excute_shell_order "cp  ${INPUTPATH}/$1		/home/so_bin" 
		else
			diff ${INPUTPATH}/$1 /home/so_bin/$1 > /dev/null 2>&1
			if [ $? -ne 0 ]; then
				#ͬ��so�ļ������ݲ�һ��
				excute_shell_order "cp  ${INPUTPATH}/$1  /home/so_bin" 
			fi
		fi
	else
		#ɾ�����ϰ汾��so��
		if ! [ -e /home/so_bin/$1 ]; then
			old_lib=`find /home/so_bin/ -name ""$lib_name"_*" |sort |awk 'NR==1'`
			excute_shell_order "rm -rf $old_lib"
			#����
			excute_shell_order "cp  ${INPUTPATH}/$1		/home/so_bin" 
		else
			diff ${INPUTPATH}/$1 /home/so_bin/$1 > /dev/null 2>&1
			if [ $? -ne 0 ]; then
				echo "`date` [BSP update]  copy" >> /home/update/update.log
				#ͬ��so�ļ������ݲ�һ��
				excute_shell_order "cp  ${INPUTPATH}/$1  /home/so_bin" 
			fi
		fi
	fi
}
update_so1()
{
	lib_name=${1%.so.*}
	lib_num=`find /home/so_bin/ -name ""$lib_name".so.*" |wc -l`

	if [ $lib_num -eq "0" ]; then
		#so�ļ������ڣ�ֱ�Ӹ���
		excute_shell_order "cp  ${INPUTPATH}/$1  /home/so_bin" 
	elif [ $lib_num -eq "1" ]; then
		if ! [ -e /home/so_bin/$1 ]; then
			#��ǰ�Ѵ��ڵ�so���ļ���Ҫ���µ�so���ļ���һ�£�����
			excute_shell_order "cp  ${INPUTPATH}/$1  /home/so_bin" 
		else
			diff ${INPUTPATH}/$1 /home/so_bin/$1 > /dev/null 2>&1
			if [ $? -ne 0 ]; then
				#ͬ��so�ļ������ݲ�һ��
				excute_shell_order "cp  ${INPUTPATH}/$1  /home/so_bin" 
			fi
		fi
	else
		#ɾ�����ϰ汾��so��
		if ! [ -e /home/so_bin/$1 ]; then
			old_lib=`find /home/so_bin/ -name ""$lib_name".so.*" |sort |awk 'NR==1'`
			excute_shell_order "rm -rf $old_lib"
			#����
			excute_shell_order "cp  ${INPUTPATH}/$1  /home/so_bin" 
		else
			diff ${INPUTPATH}/$1 /home/so_bin/$1 > /dev/null 2>&1
			if [ $? -ne 0 ]; then
				echo "`date` [BSP update]  copy" >> /home/update/update.log
				#ͬ��so�ļ������ݲ�һ��
				excute_shell_order "cp  ${INPUTPATH}/$1  /home/so_bin" 
			fi
		fi
	fi
}

# ���û�в���������
if [ $# -lt 1 ]; then	
	echo "[Uage] ./update.sh xxxx.tar.gz updateall"
	echo $#
	return 0
fi

# �����������������֤����2 �Ƿ�Ϊ ��updateall��
if [ $# -eq 2 ]; then	
	if [ $2 != "updateall" ]; then
		echo "[Uage] ./update.sh xxxx.tar.gz updateall"
		return 0
	fi
fi


if [ ! -d /home/update ];then
	mkdir /home/update
fi

if [ ! -d /mnt/app_bin0/bin_arm ];then
	mkdir /mnt/app_bin0/bin_arm
fi

if [ ! -d /mnt/app_bin1/bin_arm ];then
	mkdir /mnt/app_bin1/bin_arm
fi

if [ -e /home/update/update.log ]; then
	if [ `du -k /home/update/update.log |awk '{print $1}'` -gt 100 ]; then
		mv /home/update/update.log /home/update/update_bak.log
	fi
fi

SCRIPT_VERSION=V1.0.2
BSP_VERSION=`version`
pidof app_arm > /dev/null 2>&1
if [ $? -eq 0 ]; then
	RUNNING_APP=`cat /proc/\`pidof app_arm\`/cmdline`
	if [ -e ${RUNNING_APP%app_arm*}config/version ]; then
		APP_VERSION=`cat ${RUNNING_APP%app_arm*}config/version`
	fi
else
	#Ĭ�ϵ�ǰ���е���app1�������Ϳ���Ĭ������app0
	RUNNING_APP="/mnt/app_bin1/bin_arm/app_arm"
fi


INPUTFILENAME=$1	
INPUTNAME=${INPUTFILENAME##*/}	
INPUTPATH=${INPUTFILENAME%${INPUTNAME}*}

if [ ${#INPUTPATH} -eq 0 ];then
	INPUTPATH=`pwd`
fi

echo -e "\n`date` [APP update] INFO: ==============APP update Start==============" >> /home/update/update.log
echo "`date` [APP update] INFO:   Script  Version: $SCRIPT_VERSION" >> /home/update/update.log
echo "`date` [APP update] INFO:   BSP     Version:${BSP_VERSION##*:}" >> /home/update/update.log
echo "`date` [APP update] INFO:   Product Version: ${APP_VERSION##*=}" >> /home/update/update.log
echo "`date` [APP update] INFO: ============================================" >> /home/update/update.log

#һ����������һ�����ͽ���APP���̼�keeper
if [ $# -eq 2 ]; then
	if [ $2 == "updateall" ]; then
		exit_app_process
		if [ $? -ne 0 ]; then
			#echo "ERR: exit app process error"
			return 1
		fi
		
		#ɾ��ռ��/mnt/app_bin0��/mnt/app1�Ľ���
		kill -9 `fuser -m /mnt/app_bin0`
		kill -9 `fuser -m /mnt/app_bin1`
		
		#ɾ��home/so_bin�µ�so���ļ�----xincheng��luojinquan 2015/8/31
		if [ -d /home/so_bin ];then
			watch_app_arm
			excute_shell_order "rm -rf /home/so_bin/*"
		fi
	fi
fi

#watch dog
watch_app_arm

echo "`date` decompress update package..." >> /home/update/update.log
echo "decompress update package..."
if IsTargzFile $1; then
	watch_app_arm
	tar -zxf $1  -C $INPUTPATH 
	if  [ $? -eq 1 ]
	then
		echo "`date` [APP update]  ERR: tar $1 fail">> /home/update/update.log
		echo "ERR: tar $1 fail"
		return 2
	fi
elif IsZipFile $1; then
	watch_app_arm
	unzip -o $1   
	if  [ $? -eq 1 ]
	then
		echo "`date` [APP update]  ERR: unzip $1 fail" >> /home/update/update.log
		echo "ERR: unzip $1 fail"
		return 3
	fi
else
	echo "`date` [APP update]  ERR: unsupported update package" >> /home/update/update.log
	echo "ERR: unsupported update package"
	return 4
fi	

#determine which partion to update 
echo $RUNNING_APP | grep app_bin0 > /dev/null 2>&1
if [ $? -eq 0 ];then
	TARGET_PATH=/mnt/app_bin1/bin_arm/
	OTHER_TARGET_PATH=/mnt/app_bin0/bin_arm/
else 
	TARGET_PATH=/mnt/app_bin0/bin_arm/
	OTHER_TARGET_PATH=/mnt/app_bin1/bin_arm/
fi

#app can modify the following codes to customize updating scheme
echo "`date` update app to $TARGET_PATH..." >> /home/update/update.log
echo "update app to $TARGET_PATH..."
#backup bspversioninfo.emap

if [ -e $TARGET_PATH/bspversioninfo.emap ];then
	cp $TARGET_PATH/bspversioninfo.emap /tmp/bspversioninfo.emap
fi

if [ -d $TARGET_PATH ];then
	watch_app_arm
	excute_shell_order "rm -rf $TARGET_PATH/*"
fi 

if [ -e /tmp/bspversioninfo.emap ];then
	cp /tmp/bspversioninfo.emap $TARGET_PATH/bspversioninfo.emap
	rm /tmp/bspversioninfo.emap
fi

#remove 
#excute_shell_order "rm -rf $TARGET_PATH/*"	

#update
excute_shell_order "cp  ${INPUTPATH}/app.cfg        	$TARGET_PATH"
echo "INFO: cp ${INPUTPATH}/app_arm..."
excute_shell_order "cp  ${INPUTPATH}/app_arm		$TARGET_PATH"
excute_shell_order "cp  ${INPUTPATH}/init_env		$TARGET_PATH"
watch_app_arm

if [ -e ${INPUTPATH}/web_server ]; then
	echo "INFO: ${INPUTPATH}/web_server..."
	excute_shell_order "cp  ${INPUTPATH}/web_server		$TARGET_PATH" 
fi

if [ -d ${INPUTPATH}/config ]; then
	echo "INFO: cp ${INPUTPATH}/config..."
	excute_shell_order "cp -rf ${INPUTPATH}/config		$TARGET_PATH"
fi

if [ -d ${INPUTPATH}/webpage ]; then
	echo "INFO: cp ${INPUTPATH}/webpage..."
	excute_shell_order "cp -rf ${INPUTPATH}/webpage 	$TARGET_PATH"
fi

if [ -e ${INPUTPATH}/auth.txt ]; then
	excute_shell_order "cp  ${INPUTPATH}/auth.txt		$TARGET_PATH"
fi

if [ -e ${INPUTPATH}/ca.crt ]; then
	excute_shell_order "cp  ${INPUTPATH}/ca.crt		$TARGET_PATH"
fi

if [ -e ${INPUTPATH}/debug_define.conf ]; then
	excute_shell_order "cp  ${INPUTPATH}/debug_define.conf	$TARGET_PATH"
fi

if [ -e ${INPUTPATH}/debugging ]; then
	excute_shell_order "cp  ${INPUTPATH}/debugging		$TARGET_PATH"
fi

if [ -e ${INPUTPATH}/route.txt ]; then
	excute_shell_order "cp  ${INPUTPATH}/route.txt		$TARGET_PATH"
fi

if [ -e ${INPUTPATH}/snmp_cfg.bin ]; then
	excute_shell_order "cp  ${INPUTPATH}/snmp_cfg.bin	$TARGET_PATH"
fi

if [ -e ${INPUTPATH}/HUAWEI-MIB.mib ]; then
	excute_shell_order "cp  ${INPUTPATH}/HUAWEI-MIB.mib	$TARGET_PATH"
fi

if [ -e ${INPUTPATH}/tomcat_client.crt ]; then
	excute_shell_order "cp  ${INPUTPATH}/tomcat_client.crt	$TARGET_PATH"
fi

if [ -e ${INPUTPATH}/tomcat_client.key ]; then
	excute_shell_order "cp  ${INPUTPATH}/tomcat_client.key	$TARGET_PATH"
fi 

if [ -d ${INPUTPATH}/kp ]; then
	excute_shell_order "cp ${INPUTPATH}/kp/keeper /mnt/kp/" 
fi 

if [ -e ${INPUTPATH}/equiptest ]; then
	excute_shell_order "cp  ${INPUTPATH}/equiptest		$TARGET_PATH"
fi

if [ -d ${INPUTPATH}/ko ]; then
	excute_shell_order "cp -rf ${INPUTPATH}/ko		$TARGET_PATH"
fi

watch_app_arm
		
if [ -d ${INPUTPATH}/so ]; then
	excute_shell_order "cp -rf ${INPUTPATH}/so		$TARGET_PATH"
fi
		
if [ -d ${INPUTPATH}/web ]; then
	echo "INFO: cp ${INPUTPATH}/web..."
	excute_shell_order "cp -rf ${INPUTPATH}/web		$TARGET_PATH"
fi
		
if [ -e ${INPUTPATH}/gprsDial ]; then
	excute_shell_order "cp -rf ${INPUTPATH}/gprsDial	$TARGET_PATH"
fi
		
if [ -e ${INPUTPATH}/umconfig.txt ]; then
	excute_shell_order "cp -rf ${INPUTPATH}/umconfig.txt	$TARGET_PATH"
fi


#update so
if [ ! -d /home/so_bin ];then
	mkdir /home/so_bin
fi

watch_app_arm
# dopra�� ������û�ж����£���Ϊ��C01��C02dopra������������������£������ܲ�������
# 2015/08/03:dopra���ݱ�����汾�ű���������
#if [ -e ${INPUTPATH}/libdopra_2.2.0.so ];then
#	cp -rf ${INPUTPATH}/libdopra_2.2.0.so	/home/so_bin
#fi

# goahead�� ������û�и��£�����������ж�Ҫ�����£�
#if [ -e ${INPUTPATH}/libgoahead_3.1.5.so ];then
#	cp -rf ${INPUTPATH}/libgoahead_3.1.5.so	/home/so_bin
#fi
echo "`date` [APP update] INFO: libdopra_2.2.0.so Start" >> /home/update/update.log
if [ -e ${INPUTPATH}/libdopra_2.2.0.so ];then
	update_so "libdopra_2.2.0.so"
fi
echo "`date` [APP update] INFO: libdopra_2.2.0.so End" >> /home/update/update.log

if [ -e ${INPUTPATH}/libnetsnmp_5.7.1.so ];then
	update_so "libnetsnmp_5.7.1.so"
fi

if [ -e ${INPUTPATH}/libgoahead_3.1.5.so ];then
	update_so "libgoahead_3.1.5.so"
fi
watch_app_arm

if [ -e ${INPUTPATH}/libnetsnmpagent_5.7.1.so ];then
	update_so "libnetsnmpagent_5.7.1.so"
fi

if [ -e ${INPUTPATH}/libnetsnmphelpers_5.7.1.so ];then
	update_so "libnetsnmphelpers_5.7.1.so"
fi

if [ -e ${INPUTPATH}/libnetsnmpmibs_5.7.1.so ];then
	update_so "libnetsnmpmibs_5.7.1.so"
fi

watch_app_arm

echo "`date` [APP update] INFO: libssl.so.1.0.1p Start" >> /home/update/update.log
echo "INFO: ${INPUTPATH}/libssl.so.1.0.1p..."
if [ -e ${INPUTPATH}/libssl.so.1.0.1p ]; then		
	update_so1 "libssl.so.1.0.1p"
fi
echo "`date` [APP update] INFO: libssl.so.1.0.1p End" >> /home/update/update.log

echo "`date` [APP update] INFO: libcrypto.so.1.0.1p Start" >> /home/update/update.log
if [ -e ${INPUTPATH}/libcrypto.so.1.0.1p ]; then
	echo "INFO: ${INPUTPATH}/libcrypto.so.1.0.1p..."
	update_so1 "libcrypto.so.1.0.1p"
fi
echo "`date` [APP update] INFO: libcrypto.so.1.0.1p End" >> /home/update/update.log

#add begin by wuyichao ���簲ȫ�޸ģ�����ʼ��Ĭ����������ɾ���������ļ�����ʽ
if [ -e ${INPUTPATH}/user_init_cfg.emap ]; then
	echo "INFO: cp ${INPUTPATH}/user_init_cfg.emap..."
	excute_shell_order "cp -rf ${INPUTPATH}/user_init_cfg.emap		$TARGET_PATH"
fi

if [ -e ${INPUTPATH}/user_init_salt.emap ]; then
	echo "INFO: cp ${INPUTPATH}/user_init_salt.emap..."
	excute_shell_order "cp -rf ${INPUTPATH}/user_init_salt.emap		$TARGET_PATH"
fi
#end by wuyichao

if [ $# -eq 2 ]; then
    	if [ $2 = "updateall" ]; then
		echo "`date` update app to $OTHER_TARGET_PATH..." >> /home/update/update.log
		echo "update app to $OTHER_TARGET_PATH..."
		
		if [ -d $OTHER_TARGET_PATH ];then
			watch_app_arm
			excute_shell_order "rm -rf $OTHER_TARGET_PATH/*"
		fi
		
		pidof app_arm > /dev/null 2>&1
		if [ $? -eq 0 ]; then
			for kill_cnt in `seq 1 1000`
			do
				#Ϊ���ͷ�app����ռ�õ�flash�ռ䣬��app����ɱ����������watch app_arm
				echo $kill_cnt >> /home/update/update.log
				(kill -9 `pidof app_arm`) > /dev/null 2>&1
				if [ $? -eq 0 ]; then
					echo "`date` [BSP update] INFO: kill app times: $kill_cnt and watch app_arm immediately" >> /home/update/update.log
					break
				fi	
				
				usleep 10000
			done
			if [ 1000 -eq $kill_cnt ];then
				echo "`date` [BSP update]  ERR: can not kill app" >> /home/update/update.log
				echo "ERR: can not kill app"
				return 1
			fi
		fi
		usleep 500000
		watch_app_arm
		
		excute_shell_order "cp  ${INPUTPATH}/app.cfg        	$OTHER_TARGET_PATH"
		excute_shell_order "cp  ${INPUTPATH}/app_arm		$OTHER_TARGET_PATH"
		excute_shell_order "cp  ${INPUTPATH}/init_env		$OTHER_TARGET_PATH"

		if [ -e ${INPUTPATH}/web_server ]; then
			echo "INFO: ${INPUTPATH}/web_server..."
			excute_shell_order "cp  ${INPUTPATH}/web_server		$OTHER_TARGET_PATH" 
		fi

		if [ -d ${INPUTPATH}/config ]; then
			echo "INFO: cp ${INPUTPATH}/config..."
			excute_shell_order "cp -rf ${INPUTPATH}/config		$OTHER_TARGET_PATH"
		fi

		if [ -d ${INPUTPATH}/webpage ]; then
			echo "INFO: cp ${INPUTPATH}/webpage..."
			excute_shell_order "cp -rf ${INPUTPATH}/webpage 	$OTHER_TARGET_PATH"
		fi

		if [ -e ${INPUTPATH}/auth.txt ]; then
			excute_shell_order "cp  ${INPUTPATH}/auth.txt		$OTHER_TARGET_PATH"
		fi

		if [ -e ${INPUTPATH}/ca.crt ]; then
			excute_shell_order "cp  ${INPUTPATH}/ca.crt		$OTHER_TARGET_PATH"
		fi

		if [ -e ${INPUTPATH}/debug_define.conf ]; then
			excute_shell_order "cp  ${INPUTPATH}/debug_define.conf	$OTHER_TARGET_PATH"
		fi

		if [ -e ${INPUTPATH}/debugging ]; then
			excute_shell_order "cp  ${INPUTPATH}/debugging		$OTHER_TARGET_PATH"
		fi

		if [ -e ${INPUTPATH}/route.txt ]; then
			excute_shell_order "cp  ${INPUTPATH}/route.txt		$OTHER_TARGET_PATH"
		fi

		if [ -e ${INPUTPATH}/snmp_cfg.bin ]; then
			excute_shell_order "cp  ${INPUTPATH}/snmp_cfg.bin	$OTHER_TARGET_PATH"
		fi

		if [ -e ${INPUTPATH}/tomcat_client.crt ]; then
			excute_shell_order "cp  ${INPUTPATH}/tomcat_client.crt	$OTHER_TARGET_PATH"
		fi

		if [ -e ${INPUTPATH}/tomcat_client.key ]; then
			excute_shell_order "cp  ${INPUTPATH}/tomcat_client.key	$OTHER_TARGET_PATH"
		fi
		
		if [ -e ${INPUTPATH}/equiptest ]; then
			excute_shell_order "cp  ${INPUTPATH}/equiptest		$OTHER_TARGET_PATH"
		fi
		
		if [ -e /mnt/log/update/config.kp ]; then
			excute_shell_order "rm -rf /mnt/log/update/config.kp"
		fi
		
		if [ -d /mnt/log ]; then
			excute_shell_order "rm -rf /mnt/log/*"
		fi
			
		#C00�汾��ͳ����־Ҳ����/home���棬��Ҫɾ��
		rm -rf /home/statistic
		
		if [ -d /home/sys_cfg ]; then
			excute_shell_order "rm -rf /home/sys_cfg"
		fi		
		
			rm -rf /mnt/sub_bin/* 
					
		if [ -d ${INPUTPATH}/ko ]; then
			excute_shell_order "cp -rf ${INPUTPATH}/ko		$OTHER_TARGET_PATH"
		fi
		
		watch_app_arm
		if [ -d ${INPUTPATH}/so ]; then
			excute_shell_order "cp -rf ${INPUTPATH}/so		$OTHER_TARGET_PATH"
		fi
		
		if [ -d ${INPUTPATH}/web ]; then
			echo "INFO: cp ${INPUTPATH}/web..."
			excute_shell_order "cp -rf ${INPUTPATH}/web		$OTHER_TARGET_PATH"
		fi
		
		if [ -e ${INPUTPATH}/gprsDial ]; then
			excute_shell_order "cp -rf ${INPUTPATH}/gprsDial	$OTHER_TARGET_PATH"
		fi
		
		if [ -e ${INPUTPATH}/umconfig.txt ]; then
			excute_shell_order "cp -rf ${INPUTPATH}/umconfig.txt	$OTHER_TARGET_PATH"
		fi
		#add begin by wuyichao ���簲ȫ�޸ģ�����ʼ��Ĭ����������ɾ���������ļ�����ʽ
		if [ -e ${INPUTPATH}/user_init_cfg.emap ]; then
			echo "INFO: cp ${INPUTPATH}/user_init_cfg.emap..."
			excute_shell_order "cp -rf ${INPUTPATH}/user_init_cfg.emap		$OTHER_TARGET_PATH"
		fi

		if [ -e ${INPUTPATH}/user_init_salt.emap ]; then
			echo "INFO: cp ${INPUTPATH}/user_init_salt.emap..."
			excute_shell_order "cp -rf ${INPUTPATH}/user_init_salt.emap		$OTHER_TARGET_PATH"
		fi
		if [ -e ${INPUTPATH}/HUAWEI-MIB.mib ]; then
			excute_shell_order "cp  ${INPUTPATH}/HUAWEI-MIB.mib	$OTHER_TARGET_PATH"
		fi
		#end by wuyichao
	else
		echo "para err [Uage] ./update.sh xxxx.tar.gz updateall"
		return 1
    	fi
else
  	ChangeAppStartPath	  	
fi 

#app can modify the above codes to customize updating scheme

echo "`date` [APP update] INFO: app update success" >> /home/update/update.log
echo "OK"
return 0

