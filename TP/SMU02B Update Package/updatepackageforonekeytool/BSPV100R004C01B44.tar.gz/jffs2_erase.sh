#!/bin/sh

#check input argument to avoid misuse
if ! [ $# -eq 1 -a "$1" == "jffs2_code" ]; then
	echo "WARNING: the script will cause all data lost"
	echo "[Uage] ./jffs2_erase.sh jffs2_code"
	return 1
fi

if [ ! -d /home/update ];then
	mkdir /home/update
fi

if [ -e /home/update/update.log ]; then
	if [ `du -k /home/update/update.log |awk '{print $1}'` -gt 100 ]; then
		mv /home/update/update.log /home/update/update_bak.log
	fi
fi

SCRIPT_VERSION=V1.0.3
BSP_VERSION=`version`
pidof app_arm > /dev/null 2>&1
if [ $? -eq 0 ]; then
	RUNNING_APP=`cat /proc/\`pidof app_arm\`/cmdline`
	if [ -e ${RUNNING_APP%app_arm*}config/version ]; then
		APP_VERSION=`cat ${RUNNING_APP%app_arm*}config/version`
	fi
fi
MTD_MOUNT_LIST=$(mount |grep jffs2 |awk '{print $3}')

echo "`ps |grep 'init\|\[\|sshd\|/bin/sh\|-ash\|-bash\|usleep\|COMMAND\|telnetd' |grep -v grep |awk '{print $1}'`" > /tmp/protected_proccess
echo "`ps |grep -v grep |awk '{print $1}'`" > /tmp/all_proccess

echo -e "\n`date` [jffs2 erase] INFO: ==============JFFS2 erase Start==============">> /home/update/update.log
echo "`date` [jffs2 erase] INFO:   Script  Version: $SCRIPT_VERSION">> /home/update/update.log
echo "`date` [jffs2 erase] INFO:   BSP     Version:${BSP_VERSION##*:}">> /home/update/update.log
echo "`date` [jffs2 erase] INFO:   Product Version: ${APP_VERSION##*=}">> /home/update/update.log
echo "`date` [jffs2 erase] INFO: ============================================">> /home/update/update.log

#watch dog
(while : ; do (echo '' > /dev/watchdog) > /dev/null 2>&1; usleep 10000 ; done ;) &

#kill app process
echo "`date` [jffs2 erase] INFO: kill app process..." >> /home/update/update.log
echo "kill app process..."	
for i in `seq 1 10`
do
	kill_cnt=0
	for process_id in `awk 'NR==FNR{a[$1]}NR>FNR&&!($1 in a)' /tmp/protected_proccess /tmp/all_proccess`
	do
		if [ -d /proc/$process_id ]; then
			KILL_FAIL_PROCESS=$process_id
			kill -9 $process_id > /dev/null 2>&1
			let "kill_cnt++"
		fi
	done
	if [ "$kill_cnt" -eq "0" ]; then
		echo "`date` [jffs2 erase] INFO: kill app process success">> /home/update/update.log
		break
	fi
	if [ 10 -eq $i ]; then		
		echo "`date` [jffs2 erase]  ERR: can not kill thread:`ps |grep $KILL_FAIL_PROCESS |grep -v grep |awk '{print $5}'`">> /home/update/update.log
		echo "`date` [jffs2 erase] INFO: ==========The Threads' Information==========">> /home/update/update.log
		echo "`top -n 1`" >> /home/update/update.log
		echo "`date` [jffs2 erase] INFO: ============================================">> /home/update/update.log
		echo "ERR: can not kill thread:`ps |grep $KILL_FAIL_PROCESS |grep -v grep |awk '{print $5}'`">> /home/update/update.log
		return 2
	fi
	sleep 2
done	

cp /mnt/kp/etc/passwd /etc/passwd > /dev/null 2>&1	#����ε����ߺ��޷��ٴ�����������

#umount jffs2 mtdblock
echo "`date` [jffs2 erase] INFO: umount jffs2 mtdblock...">> /home/update/update.log
echo "umount jffs2 mtdblock..."
for mountname in $MTD_MOUNT_LIST
do
	umount -f $mountname
	if [ "$?" -ne "0" ]
	then 
		(echo "`date` [jffs2 erase]  ERR: can not umount $mountname" >> /home/update/update.log) > /dev/null 2>&1
		(echo "`date` [jffs2 erase] INFO: ==========The Threads' Information==========">> /home/update/update.log) > /dev/null 2>&1
		(echo "`ps`" >> /home/update/update.log) > /dev/null 2>&1
		(echo "`date` [jffs2 erase] INFO: ============================================">> /home/update/update.log) > /dev/null 2>&1
		echo "ERR: can not umount $mountname"
		return 3
	fi
done
(echo "`date` [jffs2 erase] INFO: umount jffs2 mtdblock success">> /home/update/update.log) > /dev/null 2>&1

#erase jffs2 mtdblock
(echo "`date` [jffs2 erase] INFO: erasing jffs2 mtdblock...">> /home/update/update.log) > /dev/null 2>&1
echo "erasing jffs2 mtdblock..."
for mtdindex in `seq 6 11`
do
	echo "erasing /dev/mtd${mtdindex}..."
	flash_eraseall -q /dev/mtd${mtdindex}
	if [ "$?" -ne "0" ]
	then 
		(echo "`date` [jffs2 erase]  ERR: can not erase /dev/mtd${mtdindex}" >> /home/update/update.log) > /dev/null 2>&1
		echo "ERR: can not erase /dev/mtd${mtdindex}"
		return 4
	fi
done
(echo "`date` [jffs2 erase] INFO: erase jffs2 mtdblock success">> /home/update/update.log) > /dev/null 2>&1
echo "OK"
return 0

