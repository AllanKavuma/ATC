#!/bin/sh

KERNEL_FILE=uImage_smu
ROOTFS_FILE=rootfs.img
ENV_PARA_FILE0=boot_para0.bin
ENV_PARA_FILE1=boot_para1.bin
TOOL_MKIMAGE=mkimage
TOOL_ERASE_SECTOR=flash-erase-sector
ENV_PARA_MTD=/dev/mtd1
KERNEL0_MTD=/dev/mtd2
ROOTFS0_MTD=/dev/mtd3
KERNEL1_MTD=/dev/mtd4
ROOTFS1_MTD=/dev/mtd5

ENV_128M_POS=160
ENV_128M_SECTOR=10
KERNEL0_128M_POS=50180000
KERNEL1_128M_POS=50e80000
ROOTFS0_128M_POS=50480000
ROOTFS1_128M_POS=51180000

ENV_64M_POS=32
ENV_64M_SECTOR=2
KERNEL0_64M_POS=50080000
KERNEL1_64M_POS=50980000
ROOTFS0_64M_POS=50380000
ROOTFS1_64M_POS=50c80000

init_para()
{	
    dd if=$ENV_PARA_MTD of=/tmp/upgrade/boot-para-bk skip=$ENV_64M_POS bs=8k count=1 > /dev/null 2>&1
	grep "bootcmd" /tmp/upgrade/boot-para-bk |grep -i "$KERNEL1_64M_POS" |grep -i "$ROOTFS1_64M_POS" > /dev/null 2>&1
    if [ $? -eq 0 ];then
    #current workstataion is 1, change to 0 after update
    	CURRENT=1
    	ENV_PARA_FILE=${INPUTPATH}/${ENV_PARA_FILE0}
    	KERNEL_MTD=$KERNEL0_MTD
    	ROOTFS_MTD=$ROOTFS0_MTD
		ENV_POS=$ENV_64M_POS
        ENV_SECTOR=$ENV_64M_SECTOR
	    KERNEL0_POS=$KERNEL0_64M_POS
	    KERNEL1_POS=$KERNEL1_64M_POS
	    ROOTFS0_POS=$ROOTFS0_64M_POS
	    ROOTFS1_POS=$ROOTFS1_64M_POS
		echo "`date` [BSP update] INFO: flashsize = 64M, current = $CURRENT" >> /home/update/update.log
		return 0
	fi
	dd if=$ENV_PARA_MTD of=/tmp/upgrade/boot-para-bk skip=$ENV_64M_POS bs=8k count=1 > /dev/null 2>&1
    grep "bootcmd" /tmp/upgrade/boot-para-bk |grep -i "$KERNEL0_64M_POS" |grep -i "$ROOTFS0_64M_POS" > /dev/null 2>&1
    if [ $? -eq 0 ];then
    #current workstataion is 0, change to 1 after update
    	CURRENT=0
    	ENV_PARA_FILE=${INPUTPATH}/${ENV_PARA_FILE1}
    	KERNEL_MTD=$KERNEL1_MTD
    	ROOTFS_MTD=$ROOTFS1_MTD
		ENV_POS=$ENV_64M_POS
        ENV_SECTOR=$ENV_64M_SECTOR
	    KERNEL0_POS=$KERNEL0_64M_POS
	    KERNEL1_POS=$KERNEL1_64M_POS
	    ROOTFS0_POS=$ROOTFS0_64M_POS
	    ROOTFS1_POS=$ROOTFS1_64M_POS
		echo "`date` [BSP update] INFO: flashsize = 64M, current = $CURRENT" >> /home/update/update.log
		return 0
    fi
	dd if=$ENV_PARA_MTD of=/tmp/upgrade/boot-para-bk skip=$ENV_128M_POS bs=8k count=1 > /dev/null 2>&1
    grep "bootcmd" /tmp/upgrade/boot-para-bk |grep -i "$KERNEL1_128M_POS" |grep -i "$ROOTFS1_128M_POS" > /dev/null 2>&1
    if [ $? -eq 0 ];then
    #current workstataion is 1, change to 0 after update
    	CURRENT=1
    	ENV_PARA_FILE=${INPUTPATH}/${ENV_PARA_FILE0}
    	KERNEL_MTD=$KERNEL0_MTD
    	ROOTFS_MTD=$ROOTFS0_MTD
		ENV_POS=$ENV_128M_POS
        ENV_SECTOR=$ENV_128M_SECTOR
	    KERNEL0_POS=$KERNEL0_128M_POS
	    KERNEL1_POS=$KERNEL1_128M_POS
	    ROOTFS0_POS=$ROOTFS0_128M_POS
	    ROOTFS1_POS=$ROOTFS1_128M_POS
		echo "`date` [BSP update] INFO: flashsize = 128M, current = $CURRENT" >> /home/update/update.log
		return 0
	fi
	dd if=$ENV_PARA_MTD of=/tmp/upgrade/boot-para-bk skip=$ENV_128M_POS bs=8k count=1 > /dev/null 2>&1
    grep "bootcmd" /tmp/upgrade/boot-para-bk |grep -i "$KERNEL0_128M_POS" |grep -i "$ROOTFS0_128M_POS" > /dev/null 2>&1
    if [ $? -eq 0 ];then
    #current workstataion is 0, change to 1 after update
    	CURRENT=0
    	ENV_PARA_FILE=${INPUTPATH}/${ENV_PARA_FILE1}
    	KERNEL_MTD=$KERNEL1_MTD
    	ROOTFS_MTD=$ROOTFS1_MTD
		ENV_POS=$ENV_128M_POS
        ENV_SECTOR=$ENV_128M_SECTOR
	    KERNEL0_POS=$KERNEL0_128M_POS
	    KERNEL1_POS=$KERNEL1_128M_POS
	    ROOTFS0_POS=$ROOTFS0_128M_POS
	    ROOTFS1_POS=$ROOTFS1_128M_POS
		echo "`date` [BSP update] INFO: flashsize = 128M, current = $CURRENT" >> /home/update/update.log
		return 0
    fi
return 1
}

#update $2 using new file
upgrade_image()
{
	${INPUTPATH}/${TOOL_MKIMAGE} -c $1 > /dev/null 2>&1
	if [ $? -ne 0 ];then
		echo "`date` [BSP update]  ERR: verify $1 fail before update" >> /home/update/update.log
		return 1
	fi
	
	flash_eraseall $2 > /dev/null 2>&1
	if [ $? -ne 0 ];then
		echo "`date` [BSP update]  ERR: erase $2 fail before update" >> /home/update/update.log
		return 1
	fi
	
	watch_app_arm
	
	dd if=$1 of=$2 bs=128k > /dev/null 2>&1
	if [ $? -ne 0 ];then
		echo "`date` [BSP update]  ERR: can not write $1 into $2" >> /home/update/update.log
		return 1
	fi	
		
	watch_app_arm

	return 0
}

#����app_arm���̣����������ɱ��ռ��/dev/watchdog�Ľ���������ι��
watch_app_arm()
{
	pidof app_arm > /dev/null 2>&1
	app_arm_flag=$?
	pidof LcdGui > /dev/null 2>&1
	LcdGui_flag=$?
	if [ $app_arm_flag -ne 0 -a $LcdGui_flag -ne 0 ]; then
		for kill_cnt in `seq 1 1000`
		do
			(watchdog -t 10ms /dev/watchdog) > /dev/null 2>&1
			if [ $? -eq 0 ]; then
				echo "`date` [BSP update] WARN: app isn't running, kill keeper times: $kill_cnt" >> /home/update/update.log
				return 0
			fi
			
			RUNNING_PROCESS=`ps |grep -v grep |awk '{print $1}' |grep -v PID`
			for process_id in $RUNNING_PROCESS
			do
				(ls -lh /proc/$process_id/fd |grep /dev/watchdog) >/dev/null  2>&1
				if [ $? -eq 0 ]; then 
					kill -9 $process_id
				fi
			done

			usleep 10000
		done
		echo "`date` [BSP update]  ERR: can not watch dog" >> /home/update/update.log
		echo "ERR: can not watch dog"
		exit 2
	fi
	return 0
}

if [ $# -ne 1 ]; then	
	echo "[Uage] ./bsp_update.sh bsp-upgrade.tar.gz"
	return 1
fi

INPUTPATH=`dirname $1`

if [ ! -d /home/update ];then
	mkdir /home/update
fi

if [ ! -d /tmp/upgrade ];then
	mkdir /tmp/upgrade
fi

if [ -e /home/update/update.log ]; then
	if [ `du -k /home/update/update.log |awk '{print $1}'` -gt 100 ]; then
		mv /home/update/update.log /home/update/update_bak.log
	fi
fi	

SCRIPT_VERSION=V1.2.0
BSP_VERSION=`version`
pidof app_arm > /dev/null 2>&1
if [ $? -eq 0 ]; then
	RUNNING_APP=`cat /proc/\`pidof app_arm\`/cmdline`
	if [ -e ${RUNNING_APP%app_arm*}config/version ]; then
		APP_VERSION=`cat ${RUNNING_APP%app_arm*}config/version`
	fi
fi

echo -e "\n`date` [BSP update] INFO: ==============BSP Update Start==============">> /home/update/update.log
echo "`date` [BSP update] INFO:   Script  Version: $SCRIPT_VERSION">> /home/update/update.log
echo "`date` [BSP update] INFO:   BSP     Version:${BSP_VERSION##*:}">> /home/update/update.log
echo "`date` [BSP update] INFO:   Product Version: ${APP_VERSION##*=}">> /home/update/update.log
echo "`date` [BSP update] INFO: ============================================">> /home/update/update.log

update_users()
{
	if [ "v100r004c01" == ${BSP_VERSION:9:11} ];then
		rm -rf /mnt/kp/etc/passwd
		rm -rf /mnt/kp/etc/shadow
		rm -rf /mnt/kp/etc/group
		rm -rf /mnt/kp/etc/security/opasswd
	fi
}

watch_app_arm

#tar bsp-upgrade.tar.gz
echo "`date` [BSP update] INFO: tar $1 to ${INPUTPATH}...">> /home/update/update.log
echo "tar bsp-upgrade.tar.gz..."
tar -zxf $1 -C ${INPUTPATH}
if [ "0" -ne "$?" ]; then 
	echo "`date` [BSP update]  ERR: can not tar $1 to ${INPUTPATH}" >> /home/update/update.log
	echo "ERR: can not tar bsp-upgrade.tar.gz"
	return 3
fi

watch_app_arm
#rm bsp-upgrade.tar.gz
rm -rf $1

#check files' integrality in bsp-upgrade.tar.gz
if [ ! -e ${INPUTPATH}/${KERNEL_FILE} -o ! -e ${INPUTPATH}/${ROOTFS_FILE} -o ! -e ${INPUTPATH}/${ENV_PARA_FILE0} -o ! -e ${INPUTPATH}/${ENV_PARA_FILE1} -o ! -e ${INPUTPATH}/${TOOL_MKIMAGE} -o ! -e ${INPUTPATH}/${TOOL_ERASE_SECTOR} ];then
	echo "`date` [BSP update]  ERR: can not find all requried files in $1" >> /home/update/update.log
	echo "ERR: can not find all requried files in bsp-upgrade.tar.gz"
	return 4
fi

#determine partitions needed to update 
init_para
if [ $? -ne 0 ];then
	echo "`date` [BSP update]  ERR: detect env fail" >> /home/update/update.log
	echo "ERR: detect env fail"
	return 5
fi

echo "`date` [BSP update] INFO: BSP is running on partion$CURRENT currently" >> /home/update/update.log

echo "`date` [BSP update] INFO: update kernel: $KERNEL_MTD" >> /home/update/update.log
echo "update kernel: $KERNEL_MTD..."
upgrade_image ${INPUTPATH}/${KERNEL_FILE} $KERNEL_MTD
if [ $? -ne 0 ];then
	echo "`date` [BSP update]  ERR: update kernel $KERNEL_MTD fail" >> /home/update/update.log
	echo "ERR: update kernel $KERNEL_MTD fail"
	return 6
fi

#Check kernel image
${INPUTPATH}/${TOOL_MKIMAGE} -c $KERNEL_MTD | grep 'Linux-2.6.27-SPEAr310' > /dev/null 2>&1
if [ $? -ne 0 ];then
	echo "`date` [BSP update]  ERR: verify $KERNEL_MTD fail after update" >> /home/update/update.log
	echo "ERR: verify $KERNEL_MTD fail after update"
	return 7
fi

echo "`date` [BSP update] INFO: update rootfs: $ROOTFS_MTD" >> /home/update/update.log
echo "update rootfs: $ROOTFS_MTD..."
upgrade_image ${INPUTPATH}/${ROOTFS_FILE} $ROOTFS_MTD
if [ $? -ne 0 ];then
	echo "`date` [BSP update]  ERR: update rootfs $ROOTFS_MTD fail" >> /home/update/update.log
	echo "ERR: update rootfs $ROOTFS_MTD fail"
	return 8
fi

#Check rootfs image
${INPUTPATH}/${TOOL_MKIMAGE} -c $ROOTFS_MTD | grep initramfs > /dev/null 2>&1
if [ $? -ne 0 ];then
	echo "`date` [BSP update]  ERR: verify $ROOTFS_MTD fail after update" >> /home/update/update.log
	echo "ERR: verify $ROOTFS_MTD fail after update"
	return 9
fi

#backup uboot environment args
dd if=$ENV_PARA_MTD of=/tmp/upgrade/boot-para-bk skip=$ENV_POS bs=8k count=1 > /dev/null 2>&1
if [ $? -ne 0 ];then
	echo "`date` [BSP update]  ERR: backup uboot environment args fail" >> /home/update/update.log
	echo "ERR: backup uboot environment args fail"
	return 10
fi

echo "`date` [BSP update] INFO: write new uboot environment args" >> /home/update/update.log
${INPUTPATH}/${TOOL_ERASE_SECTOR} $ENV_PARA_MTD $ENV_SECTOR 1 > /dev/null 2>&1
if [ $? -ne 0 ];then
	echo "`date` [BSP update]  ERR: erase uboot environment args fail" >> /home/update/update.log
	echo "ERR: erase uboot environment args fail"
	return 11
fi

dd if=$ENV_PARA_FILE of=$ENV_PARA_MTD seek=$ENV_POS bs=8k count=1 > /dev/null 2>&1
if [ $? -ne 0 ];then
	echo "`date` [BSP update]  ERR: write new uboot environment args fail, BSP still boot from partion$CURRENT" >> /home/update/update.log
	#write the original uboot enviroment args before update
	${INPUTPATH}/${TOOL_ERASE_SECTOR} $ENV_PARA_MTD $ENV_SECTOR 1 > /dev/null 2>&1
	dd if=/tmp/upgrade/boot-para-bk of=$ENV_PARA_MTD seek=$ENV_POS bs=8k count=1 > /dev/null 2>&1
	echo "ERR: write new uboot env args fail, recover it"
	return 12
fi

#Check boot para.
if [ $CURRENT -eq 0 ];then
	grep -i "$KERNEL1_POS" $ENV_PARA_MTD |grep -i "$ROOTFS1_POS" > /dev/null 2>&1
	if [ $? -eq 0 ];then
		rm -rf /tmp/upgrade/
		update_users
		echo "`date` [BSP update] INFO: BSP update success, now BSP will boot from partion1" >> /home/update/update.log
		echo "OK"
		return 0
	fi
else 
	grep -i "$KERNEL0_POS" $ENV_PARA_MTD |grep -i "$ROOTFS0_POS" > /dev/null 2>&1
	if [ $? -eq 0 ];then
		rm -rf /tmp/upgrade/
		update_users
		echo "`date` [BSP update] INFO: BSP update success, now BSP will boot from partion0" >> /home/update/update.log
		echo "OK"
		return 0
	fi
fi

#fail to upgrade BSP. Recover boot para.
${INPUTPATH}/${TOOL_ERASE_SECTOR} $ENV_PARA_MTD $ENV_SECTOR 1 > /dev/null 2>&1
dd if=/tmp/upgrade/boot-para-bk of=$ENV_PARA_MTD seek=$ENV_POS bs=8k count=1 > /dev/null 2>&1
echo "`date` [BSP update]  ERR: check boot para error, BSP still boot from partion$CURRENT" >> /home/update/update.log
echo "ERR: check boot para error, recover it"
return 13
